import { Fragment, createElement, useCallback, type ReactNode } from "react";
import { useUIStore } from "../stores/ui.store";

type TranslationDict = Record<string, string>;

const localeModules = import.meta.glob("./locales/*/*.json", {
  eager: true,
  import: "default",
}) as Record<string, TranslationDict>;

const TRANSLATIONS: Record<string, TranslationDict> = {};
const KEY_REFERENCE_PREFIX = "@:";
const MAX_REFERENCE_DEPTH = 10;

for (const [path, dict] of Object.entries(localeModules)) {
  const match = path.match(/^\.\/locales\/([^/]+)\/[^/]+\.json$/);
  if (!match) continue;
  const language = match[1];
  if (!TRANSLATIONS[language]) TRANSLATIONS[language] = {};
  Object.assign(TRANSLATIONS[language], dict);
}

export function translate(language: string, key: string, fallback: string): string {
  const dict = TRANSLATIONS[language];
  if (!dict) return fallback;

  const visited = new Set<string>();
  let currentKey = key;

  for (let depth = 0; depth < MAX_REFERENCE_DEPTH; depth += 1) {
    if (visited.has(currentKey)) return fallback;
    visited.add(currentKey);

    const localized = dict[currentKey];
    if (typeof localized !== "string" || localized.length === 0) return fallback;

    if (!localized.startsWith(KEY_REFERENCE_PREFIX)) return localized;

    const nextKey = localized.slice(KEY_REFERENCE_PREFIX.length).trim();
    if (!nextKey) return fallback;
    currentKey = nextKey;
  }

  return fallback;
}

export function useT() {
  const language = useUIStore((s) => s.language);
  return useCallback((key: string, fallback: string) => translate(language, key, fallback), [language]);
}

type RichMap = Record<string, ReactNode>;

export function useTRich() {
  const i18n = useT();

  return useCallback((key: string, fallback: string, rich: RichMap) => {
    const text = i18n(key, fallback);
    const parts = text.split(/(\{[a-zA-Z0-9_]+\})/g);

    return parts.map((part, i) => {
      const m = part.match(/^\{([a-zA-Z0-9_]+)\}$/);
      if (!m) return createElement(Fragment, { key: i }, part);
      return createElement(Fragment, { key: i }, rich[m[1]] ?? part);
    });
  }, [i18n]);
}
