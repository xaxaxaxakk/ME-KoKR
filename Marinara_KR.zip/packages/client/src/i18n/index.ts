import { Fragment, createElement, type ReactNode } from "react";
import { useUIStore } from "../stores/ui.store";

type TranslationDict = Record<string, string>;

const localeModules = import.meta.glob("./locales/*/*.json", {
  eager: true,
  import: "default",
}) as Record<string, TranslationDict>;

const TRANSLATIONS: Record<string, TranslationDict> = {};

for (const [path, dict] of Object.entries(localeModules)) {
  const match = path.match(/^\.\/locales\/([^/]+)\/[^/]+\.json$/);
  if (!match) continue;
  const language = match[1];
  if (!TRANSLATIONS[language]) TRANSLATIONS[language] = {};
  Object.assign(TRANSLATIONS[language], dict);
}

export function translate(language: string, key: string, fallback: string): string {
  const localized = TRANSLATIONS[language]?.[key];
  if (typeof localized === "string") {
    if (localized === " ") return "";
    if (localized.length > 0) return localized;
  }
  return fallback;
}

export function useT() {
  const language = useUIStore((s) => s.language);
  return (key: string, fallback: string) => translate(language, key, fallback);
}

type RichMap = Record<string, ReactNode>;

export function useTRich() {
  const t = useT();

  return (key: string, fallback: string, rich: RichMap) => {
    const text = t(key, fallback);
    const parts = text.split(/(\{[a-zA-Z0-9_]+\})/g);

    return parts.map((part, i) => {
      const m = part.match(/^\{([a-zA-Z0-9_]+)\}$/);
      if (!m) return createElement(Fragment, { key: i }, part);
      return createElement(Fragment, { key: i }, rich[m[1]] ?? part);
    });
  };
}
