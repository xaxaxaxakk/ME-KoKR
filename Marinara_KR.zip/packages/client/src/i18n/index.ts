import { Fragment, createElement, useCallback, useEffect, useSyncExternalStore, type ReactNode } from "react";
import { useUIStore } from "../stores/ui.store";

type TranslationDict = Record<string, string>;
type NamespaceInput = string | readonly string[];

const DEFAULT_LANGUAGE = "en";

export const STARTUP_TRANSLATION_NAMESPACES = ["common-general", "layout", "chats"] as const;

const namespaceLoaders = import.meta.glob("./locales/*/*.json", {
  import: "default",
}) as Record<string, () => Promise<TranslationDict>>;

const TRANSLATIONS: Record<string, TranslationDict> = {};
const NAMESPACE_LOADERS: Record<string, Record<string, () => Promise<TranslationDict>>> = {};
const DEFAULT_NAMESPACE_BY_KEY: Record<string, string> = {};
const loadedLanguages = new Set<string>();
const loadingLanguages = new Map<string, Promise<void>>();
const loadedNamespaces = new Set<string>();
const loadingNamespaces = new Map<string, Promise<void>>();
const warnedLanguages = new Set<string>();
const listeners = new Set<() => void>();
let translationVersion = 0;
let notificationPending = false;
let notificationScheduled = false;

const KEY_REFERENCE_PREFIX = "@:";
const MAX_REFERENCE_DEPTH = 10;
const TRANSLATION_NOTIFY_DELAY_MS = 16;

for (const [path, loader] of Object.entries(namespaceLoaders)) {
  const match = path.match(/^\.\/locales\/([^/]+)\/([^/]+)\.json$/);
  if (!match) continue;
  const [, language, namespace] = match;
  NAMESPACE_LOADERS[language] ??= {};
  NAMESPACE_LOADERS[language]![namespace] = loader;
}

function rememberDefaultNamespace(namespace: string, dict: TranslationDict) {
  for (const key of Object.keys(dict)) {
    DEFAULT_NAMESPACE_BY_KEY[key] = namespace;
  }
}

function subscribeToTranslations(listener: () => void) {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

function getTranslationVersion() {
  return translationVersion;
}

function flushTranslationListeners() {
  if (!notificationPending) {
    notificationScheduled = false;
    return;
  }

  notificationPending = false;
  notificationScheduled = false;
  translationVersion += 1;
  listeners.forEach((listener) => listener());
}

function scheduleTranslationNotification() {
  notificationPending = true;
  if (notificationScheduled) return;
  notificationScheduled = true;

  const scheduleFlush = () => {
    globalThis.setTimeout(flushTranslationListeners, TRANSLATION_NOTIFY_DELAY_MS);
  };

  if (typeof document !== "undefined" && document.hidden) {
    const flushWhenVisible = () => {
      if (document.hidden) return;
      document.removeEventListener("visibilitychange", flushWhenVisible);
      scheduleFlush();
    };
    document.addEventListener("visibilitychange", flushWhenVisible);
    return;
  }

  scheduleFlush();
}

function getNamespaceKey(language: string, namespace: string) {
  return `${language}:${namespace}`;
}

function normalizeNamespaces(namespaces: NamespaceInput | undefined): string[] {
  if (!namespaces) return [];
  return (Array.isArray(namespaces) ? namespaces : [namespaces]).filter((namespace) => namespace.length > 0);
}

function getAllNamespaces(language: string): string[] {
  return Object.keys(NAMESPACE_LOADERS[language] ?? {});
}

function getNamespaceForKey(key: string): string | undefined {
  return DEFAULT_NAMESPACE_BY_KEY[key];
}

function requestNamespaceForKey(language: string, key: string) {
  const namespace = getNamespaceForKey(key);
  if (!namespace) return;
  void loadTranslationNamespace(DEFAULT_LANGUAGE, namespace);
  if (language !== DEFAULT_LANGUAGE) {
    void loadTranslationNamespace(language, namespace);
  }
}

export function loadTranslationNamespace(language: string, namespace: string): Promise<void> {
  const key = getNamespaceKey(language, namespace);
  if (loadedNamespaces.has(key)) return Promise.resolve();

  const existing = loadingNamespaces.get(key);
  if (existing) return existing;

  const loader = NAMESPACE_LOADERS[language]?.[namespace];
  if (!loader) {
    loadedNamespaces.add(key);
    return Promise.resolve();
  }

  const promise = loader()
    .then((dict) => {
      TRANSLATIONS[language] ??= {};
      Object.assign(TRANSLATIONS[language], dict);
      if (language === DEFAULT_LANGUAGE) {
        rememberDefaultNamespace(namespace, dict);
      }
      loadedNamespaces.add(key);
      scheduleTranslationNotification();
    })
    .catch((error: unknown) => {
      const warningKey = `${language}:${namespace}`;
      if (!warnedLanguages.has(warningKey)) {
        warnedLanguages.add(warningKey);
        console.warn(
          `[i18n] Failed to load "${language}" namespace "${namespace}". Falling back to English translations.`,
          error,
        );
      }
    })
    .finally(() => {
      loadingNamespaces.delete(key);
    });

  loadingNamespaces.set(key, promise);
  return promise;
}

export async function loadTranslationNamespaces(language: string, namespaces: NamespaceInput): Promise<void> {
  await Promise.all(normalizeNamespaces(namespaces).map((namespace) => loadTranslationNamespace(language, namespace)));
}

async function loadTranslationNamespacesSerial(language: string, namespaces: string[]): Promise<void> {
  for (const namespace of namespaces) {
    await loadTranslationNamespace(language, namespace);
  }
}

export async function preloadAllTranslationNamespaces(language: string): Promise<void> {
  const namespaces = Array.from(new Set([...getAllNamespaces(DEFAULT_LANGUAGE), ...getAllNamespaces(language)]));
  await loadTranslationNamespacesSerial(DEFAULT_LANGUAGE, namespaces);
  if (language !== DEFAULT_LANGUAGE) {
    await loadTranslationNamespacesSerial(language, namespaces);
  }
}

export function useTranslationNamespaces(namespaces: NamespaceInput) {
  const language = useUIStore((s) => s.language);
  const namespaceSignature = normalizeNamespaces(namespaces).join("\0");

  useEffect(() => {
    if (!namespaceSignature) return;
    const requestedNamespaces = namespaceSignature.split("\0");
    void loadTranslationNamespaces(DEFAULT_LANGUAGE, requestedNamespaces);
    void loadTranslationNamespaces(language, requestedNamespaces);
  }, [language, namespaceSignature]);
}

export function usePreloadAllTranslationNamespaces() {
  const language = useUIStore((s) => s.language);

  useEffect(() => {
    void preloadAllTranslationNamespaces(language);
  }, [language]);
}

export async function loadTranslations(language: string, namespaces?: NamespaceInput): Promise<void> {
  const requestedNamespaces = normalizeNamespaces(namespaces);
  if (requestedNamespaces.length > 0) {
    await loadTranslationNamespaces(language, requestedNamespaces);
    return;
  }

  if (loadedLanguages.has(language)) return Promise.resolve();

  const existing = loadingLanguages.get(language);
  if (existing) return existing;

  const allNamespaces = getAllNamespaces(language);
  if (allNamespaces.length === 0) {
    loadedLanguages.add(language);
    return Promise.resolve();
  }

  const promise = loadTranslationNamespacesSerial(language, allNamespaces)
    .then(() => {
      loadedLanguages.add(language);
    })
    .catch((error: unknown) => {
      if (!warnedLanguages.has(language)) {
        warnedLanguages.add(language);
        console.warn(`[i18n] Failed to load "${language}" translations. Falling back to English translations.`, error);
      }
    })
    .finally(() => {
      loadingLanguages.delete(language);
    });

  loadingLanguages.set(language, promise);
  return promise;
}

function resolveTranslation(dict: TranslationDict | undefined, key: string): string | undefined {
  if (!dict) return undefined;

  const visited = new Set<string>();
  let currentKey = key;

  for (let depth = 0; depth < MAX_REFERENCE_DEPTH; depth += 1) {
    if (visited.has(currentKey)) return undefined;
    visited.add(currentKey);

    const localized = dict[currentKey];
    if (typeof localized !== "string" || localized.length === 0) return undefined;

    if (!localized.startsWith(KEY_REFERENCE_PREFIX)) return localized;

    const nextKey = localized.slice(KEY_REFERENCE_PREFIX.length).trim();
    if (!nextKey) return undefined;
    currentKey = nextKey;
  }

  return undefined;
}

export function translate(language: string, key: string, fallback?: string): string {
  requestNamespaceForKey(language, key);

  return (
    resolveTranslation(TRANSLATIONS[language], key) ??
    resolveTranslation(TRANSLATIONS[DEFAULT_LANGUAGE], key) ??
    fallback ??
    key
  );
}

export function useT(namespaces?: NamespaceInput) {
  const language = useUIStore((s) => s.language);
  const version = useSyncExternalStore(subscribeToTranslations, getTranslationVersion, getTranslationVersion);
  const namespaceSignature = normalizeNamespaces(namespaces).join("\0");

  useEffect(() => {
    const requestedNamespaces = namespaceSignature ? namespaceSignature.split("\0") : STARTUP_TRANSLATION_NAMESPACES;
    void loadTranslationNamespaces(DEFAULT_LANGUAGE, requestedNamespaces);
    void loadTranslationNamespaces(language, requestedNamespaces);
  }, [language, namespaceSignature]);

  return useCallback((key: string, fallback?: string) => {
    void version;
    return translate(language, key, fallback);
  }, [language, version]);
}

type RichMap = Record<string, ReactNode>;

export function useTRich(namespaces?: NamespaceInput) {
  const i18n = useT(namespaces);

  return useCallback((key: string, fallbackOrRich: string | RichMap, maybeRich?: RichMap) => {
    const fallback = typeof fallbackOrRich === "string" ? fallbackOrRich : undefined;
    const rich = typeof fallbackOrRich === "string" ? maybeRich : fallbackOrRich;
    const text = i18n(key, fallback);
    const parts = text.split(/(\{[a-zA-Z0-9_]+\})/g);

    return parts.map((part, i) => {
      const m = part.match(/^\{([a-zA-Z0-9_]+)\}$/);
      if (!m) return createElement(Fragment, { key: i }, part);
      return createElement(Fragment, { key: i }, rich?.[m[1]] ?? part);
    });
  }, [i18n]);
}
