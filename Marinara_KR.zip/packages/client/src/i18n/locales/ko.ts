type TranslationDict = Record<string, string>;

const modules = import.meta.glob("./ko/*.json", {
  eager: true,
  import: "default",
}) as Record<string, TranslationDict>;

const translations: TranslationDict = {};

for (const dict of Object.values(modules)) {
  Object.assign(translations, dict);
}

export default translations;
