#!/usr/bin/env node
import { existsSync, mkdirSync, readdirSync, readFileSync, statSync, unlinkSync, writeFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const scriptDir = dirname(fileURLToPath(import.meta.url));
const args = new Set(process.argv.slice(2));
const reverse = args.has("--reverse");
const patchFile = resolve(scriptDir, "local-i18n-bootstrap.patch");

function splitLines(text) {
  return text.replace(/\r\n/g, "\n").replace(/\r/g, "\n").split("\n");
}

function joinLines(lines, trailingNewline) {
  return `${lines.join("\n")}${trailingNewline ? "\n" : ""}`;
}

function parsePatch(patchText) {
  const lines = splitLines(patchText);
  const files = [];
  let current = null;
  let currentHunk = null;

  for (const line of lines) {
    const diffMatch = line.match(/^diff (?:--git )?a\/(.+) b\/(.+?)(?:\s|\t|$)/);
    if (diffMatch) {
      current = { path: diffMatch[2], hunks: [] };
      files.push(current);
      currentHunk = null;
      continue;
    }

    if (!current) continue;
    if (line.startsWith("@@ ")) {
      currentHunk = [];
      current.hunks.push(currentHunk);
      continue;
    }

    if (!currentHunk) continue;
    if (line.startsWith(" ") || line.startsWith("+") || line.startsWith("-")) {
      if (line.startsWith("--- ") || line.startsWith("+++ ")) continue;
      currentHunk.push({ kind: line[0], text: line.slice(1) });
    }
  }

  return files.filter((file) => file.path && file.hunks.length > 0);
}

function listRejectFiles(dir) {
  if (!existsSync(dir)) return [];
  const out = [];
  for (const entry of readdirSync(dir)) {
    const fullPath = resolve(dir, entry);
    const stat = statSync(fullPath);
    if (stat.isDirectory()) {
      out.push(...listRejectFiles(fullPath));
    } else if (entry.endsWith(".rej")) {
      out.push(fullPath);
    }
  }
  return out;
}

function indexOfBlock(lines, block) {
  if (block.length === 0 || block.length > lines.length) return -1;
  outer: for (let i = 0; i <= lines.length - block.length; i += 1) {
    for (let j = 0; j < block.length; j += 1) {
      if (lines[i + j] !== block[j]) continue outer;
    }
    return i;
  }
  return -1;
}

function hasBlock(lines, block) {
  return block.length > 0 && indexOfBlock(lines, block) !== -1;
}

function replaceBlock(lines, from, to) {
  const index = indexOfBlock(lines, from);
  if (index === -1) return false;
  lines.splice(index, from.length, ...to);
  return true;
}

function trimIndexOf(lines, needle) {
  const trimmedNeedle = needle.trim();
  if (!trimmedNeedle) return -1;
  return lines.findIndex((line) => line.trim() === trimmedNeedle);
}

function insertWithAnchor(lines, added, beforeContext, afterContext) {
  if (hasBlock(lines, added)) return false;

  for (let i = beforeContext.length - 1; i >= 0; i -= 1) {
    const anchor = beforeContext[i];
    const index = trimIndexOf(lines, anchor);
    if (index !== -1) {
      lines.splice(index + 1, 0, ...added);
      return true;
    }
  }

  for (const anchor of afterContext) {
    const index = trimIndexOf(lines, anchor);
    if (index !== -1) {
      lines.splice(index, 0, ...added);
      return true;
    }
  }

  return false;
}

function buildChangeGroups(hunk) {
  const groups = [];
  let beforeContext = [];
  let active = null;

  const closeActive = (nextContext = []) => {
    if (!active) return;
    active.afterContext = nextContext.slice(0, 4);
    groups.push(active);
    active = null;
  };

  for (const entry of hunk) {
    if (entry.kind === " ") {
      if (active) {
        closeActive([entry.text]);
      }
      beforeContext.push(entry.text);
      if (beforeContext.length > 4) beforeContext.shift();
      continue;
    }

    if (!active) {
      active = { removed: [], added: [], beforeContext: beforeContext.slice(), afterContext: [] };
    }

    if (entry.kind === "-") active.removed.push(entry.text);
    if (entry.kind === "+") active.added.push(entry.text);
  }

  closeActive([]);
  return groups;
}

function normalizeHunkForMode(hunk) {
  if (!reverse) return hunk;
  return hunk.map((entry) => {
    if (entry.kind === "+") return { kind: "-", text: entry.text };
    if (entry.kind === "-") return { kind: "+", text: entry.text };
    return entry;
  });
}

function applyHunkCompat(lines, rawHunk) {
  const hunk = normalizeHunkForMode(rawHunk);
  const oldBlock = hunk.filter((entry) => entry.kind !== "+").map((entry) => entry.text);
  const newBlock = hunk.filter((entry) => entry.kind !== "-").map((entry) => entry.text);

  if (hasBlock(lines, newBlock)) return false;
  if (replaceBlock(lines, oldBlock, newBlock)) return true;

  let changed = false;
  for (const group of buildChangeGroups(hunk)) {
    if (group.added.length > 0 && hasBlock(lines, group.added)) continue;

    if (group.removed.length > 0 && replaceBlock(lines, group.removed, group.added)) {
      changed = true;
      continue;
    }

    if (group.removed.length === 1 && group.added.length === 1) {
      const index = trimIndexOf(lines, group.removed[0]);
      if (index !== -1) {
        lines[index] = group.added[0];
        changed = true;
        continue;
      }
    }

    if (group.removed.length === 0 && group.added.length > 0) {
      if (insertWithAnchor(lines, group.added, group.beforeContext, group.afterContext)) {
        changed = true;
      }
    }
  }

  return changed;
}

function isHunkResolved(lines, rawHunk) {
  const hunk = normalizeHunkForMode(rawHunk);
  const desiredBlock = hunk.filter((entry) => entry.kind !== "-").map((entry) => entry.text);
  if (desiredBlock.length > 0 && hasBlock(lines, desiredBlock)) return true;

  for (const group of buildChangeGroups(hunk)) {
    if (group.added.length > 0 && !hasBlock(lines, group.added)) return false;
    if (group.removed.length > 0 && hasBlock(lines, group.removed)) return false;
  }

  return true;
}

function getAdditionOnlyFileLines(filePatch) {
  const lines = [];

  for (const hunk of normalizeHunkForMode(filePatch.hunks.flat())) {
    if (hunk.kind === "-") return null;
    if (hunk.kind === " ") return null;
    if (hunk.kind === "+") lines.push(hunk.text);
  }

  return lines.length > 0 ? lines : null;
}

function pruneResolvedRejects() {
  let pruned = 0;
  for (const rejectFile of listRejectFiles(resolve(scriptDir, "packages/client/src"))) {
    const targetPath = rejectFile.slice(0, -".rej".length);
    if (!existsSync(targetPath)) continue;

    const rejectPatch = readFileSync(rejectFile, "utf8");
    const parsed = parsePatch(rejectPatch);
    if (parsed.length === 0) continue;

    const targetText = readFileSync(targetPath, "utf8").replace(/\r\n/g, "\n").replace(/\r/g, "\n");
    const lines = splitLines(targetText);
    if (targetText.endsWith("\n")) lines.pop();

    const allResolved = parsed.every((filePatch) => filePatch.hunks.every((hunk) => isHunkResolved(lines, hunk)));
    if (allResolved) {
      unlinkSync(rejectFile);
      pruned += 1;
    }
  }
  return pruned;
}

if (!existsSync(patchFile)) {
  process.exit(0);
}

let changedFiles = 0;
let changedHunks = 0;
let skippedFiles = 0;

for (const filePatch of parsePatch(readFileSync(patchFile, "utf8"))) {
  const targetPath = resolve(scriptDir, filePatch.path);
  if (!existsSync(targetPath)) {
    const additionOnlyLines = getAdditionOnlyFileLines(filePatch);
    if (additionOnlyLines) {
      mkdirSync(dirname(targetPath), { recursive: true });
      writeFileSync(targetPath, joinLines(additionOnlyLines, true), "utf8");
      changedFiles += 1;
      changedHunks += filePatch.hunks.length;
      continue;
    }

    skippedFiles += 1;
    continue;
  }

  const original = readFileSync(targetPath, "utf8").replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  const trailingNewline = original.endsWith("\n");
  const lines = splitLines(original);
  if (trailingNewline) lines.pop();

  let fileChanged = false;
  for (const hunk of filePatch.hunks) {
    if (applyHunkCompat(lines, hunk)) {
      changedHunks += 1;
      fileChanged = true;
    }
  }

  if (fileChanged) {
    writeFileSync(targetPath, joinLines(lines, trailingNewline), "utf8");
    changedFiles += 1;
  }
}

if (changedFiles > 0) {
  console.log(`[INFO] Compatibility pass applied ${changedHunks} fallback hunk(s) in ${changedFiles} file(s).`);
}

const prunedRejects = pruneResolvedRejects();
if (prunedRejects > 0) {
  console.log(`[INFO] Compatibility pass cleared ${prunedRejects} resolved reject file(s).`);
}

if (skippedFiles > 0) {
  console.log(`[INFO] Compatibility pass skipped ${skippedFiles} missing file(s).`);
}
