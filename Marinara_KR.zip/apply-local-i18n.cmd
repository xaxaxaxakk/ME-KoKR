@echo off
setlocal

cd /d "%~dp0"
set "PATCH_FILE=%CD%\local-i18n-bootstrap.patch"

where git >nul 2>&1
if errorlevel 1 (
  echo [ERROR] git is required.
  exit /b 1
)

if not exist "%PATCH_FILE%" (
  echo [ERROR] Patch file not found: %PATCH_FILE%
  exit /b 1
)

if /I "%~1"=="--reverse" goto reverse

git apply --check --reverse "%PATCH_FILE%" >nul 2>&1
if not errorlevel 1 (
  echo [OK] Patch already applied. Nothing to do.
  exit /b 0
)

set "PATCH_LOG=%TEMP%\me-kokr-patch-%RANDOM%%RANDOM%.log"
git apply --3way --whitespace=nowarn "%PATCH_FILE%" >"%PATCH_LOG%" 2>&1
if errorlevel 1 (
  git apply --reject --whitespace=nowarn "%PATCH_FILE%" >>"%PATCH_LOG%" 2>&1
  if errorlevel 1 (
    if exist "%PATCH_LOG%" type "%PATCH_LOG%"
    if exist "%PATCH_LOG%" del /q "%PATCH_LOG%" >nul 2>&1
    echo [WARN] Patch apply reported conflicts.
    echo        Resolve *.rej files, then run:
    echo        your normal Marinara start script
    exit /b 1
  )
)

for /r %%F in (*.rej) do del /q "%%F" >nul 2>&1
if exist "packages\shared\dist" rmdir /s /q "packages\shared\dist"
if exist "packages\server\dist" rmdir /s /q "packages\server\dist"
if exist "packages\client\dist" rmdir /s /q "packages\client\dist"
del /q "packages\shared\tsconfig.tsbuildinfo" 2>nul
del /q "packages\server\tsconfig.tsbuildinfo" 2>nul
del /q "packages\client\tsconfig.tsbuildinfo" 2>nul
if exist "%PATCH_LOG%" del /q "%PATCH_LOG%" >nul 2>&1
echo [OK] Patch applied.
exit /b 0

:reverse
git apply --check "%PATCH_FILE%" >nul 2>&1
if not errorlevel 1 (
  echo [OK] Patch is not currently applied. Nothing to reverse.
  exit /b 0
)

set "PATCH_LOG=%TEMP%\me-kokr-patch-%RANDOM%%RANDOM%.log"
git apply --reverse --3way --whitespace=nowarn "%PATCH_FILE%" >"%PATCH_LOG%" 2>&1
if errorlevel 1 (
  git apply --reverse --reject --whitespace=nowarn "%PATCH_FILE%" >>"%PATCH_LOG%" 2>&1
  if errorlevel 1 (
    if exist "%PATCH_LOG%" type "%PATCH_LOG%"
    if exist "%PATCH_LOG%" del /q "%PATCH_LOG%" >nul 2>&1
    echo [WARN] Reverse apply reported conflicts.
    echo        Check *.rej files and resolve manually.
    exit /b 1
  )
)

for /r %%F in (*.rej) do del /q "%%F" >nul 2>&1
if exist "%PATCH_LOG%" del /q "%PATCH_LOG%" >nul 2>&1
echo [OK] Patch reversed.
exit /b 0

