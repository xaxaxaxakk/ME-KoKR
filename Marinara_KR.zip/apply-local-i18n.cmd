@echo off
setlocal

cd /d "%~dp0"
set "PATCH_FILE=%CD%\local-i18n-bootstrap.patch"

where git >nul 2>&1
if errorlevel 1 (
  echo [ERROR] git is required.
  exit /b 1
)

if not exist "%PATCH_FILE%" (
  echo [ERROR] Patch file not found: %PATCH_FILE%
  exit /b 1
)

if /I "%~1"=="--reverse" goto reverse

git apply --check --reverse "%PATCH_FILE%" >nul 2>&1
if not errorlevel 1 (
  echo [OK] Patch already applied. Nothing to do.
  exit /b 0
)

set "PATCH_LOG=%TEMP%\me-kokr-patch-%RANDOM%%RANDOM%.log"
call :cleanup_rejects
git apply --check --3way --whitespace=nowarn "%PATCH_FILE%" >"%PATCH_LOG%" 2>&1
if not errorlevel 1 (
  git apply --3way --whitespace=nowarn "%PATCH_FILE%" >>"%PATCH_LOG%" 2>&1
  if not errorlevel 1 (
    call :cleanup_rejects
    call :cleanup_build_outputs
    if exist "%PATCH_LOG%" del /q "%PATCH_LOG%" >nul 2>&1
    echo [OK] Patch applied.
    exit /b 0
  )
)

type nul >"%PATCH_LOG%"
git apply --reject --whitespace=nowarn "%PATCH_FILE%" >"%PATCH_LOG%" 2>&1
if not errorlevel 1 (
  call :cleanup_rejects
  call :cleanup_build_outputs
  if exist "%PATCH_LOG%" del /q "%PATCH_LOG%" >nul 2>&1
  echo [OK] Patch applied.
  exit /b 0
)

call :has_rejects
if not errorlevel 1 (
  if exist "%PATCH_LOG%" del /q "%PATCH_LOG%" >nul 2>&1
  call :cleanup_build_outputs
  call :apply_fallbacks
  if not errorlevel 1 (
    call :has_rejects
    if errorlevel 1 (
      echo [OK] Patch applied with compatibility fallback.
      exit /b 0
    )
  )
  echo [WARN] Patch partially applied. Rejected hunks were left as *.rej files.
  echo        Most compatible translation hunks were still applied.
  echo        Rejected files:
  call :print_rejects
  exit /b 0
)

call :apply_fallbacks
if not errorlevel 1 (
  call :has_rejects
  if errorlevel 1 (
    call :cleanup_build_outputs
    echo [OK] Patch applied with compatibility fallback.
    exit /b 0
  )
)

if exist "%PATCH_LOG%" type "%PATCH_LOG%"
if exist "%PATCH_LOG%" del /q "%PATCH_LOG%" >nul 2>&1
echo [WARN] Patch apply reported conflicts.
echo        Resolve *.rej files, then run:
echo        your normal Marinara start script
exit /b 1

:reverse
git apply --check "%PATCH_FILE%" >nul 2>&1
if not errorlevel 1 (
  echo [OK] Patch is not currently applied. Nothing to reverse.
  exit /b 0
)

set "PATCH_LOG=%TEMP%\me-kokr-patch-%RANDOM%%RANDOM%.log"
call :cleanup_rejects
git apply --check --reverse --3way --whitespace=nowarn "%PATCH_FILE%" >"%PATCH_LOG%" 2>&1
if not errorlevel 1 (
  git apply --reverse --3way --whitespace=nowarn "%PATCH_FILE%" >>"%PATCH_LOG%" 2>&1
  if not errorlevel 1 (
    call :cleanup_rejects
    if exist "%PATCH_LOG%" del /q "%PATCH_LOG%" >nul 2>&1
    echo [OK] Patch reversed.
    exit /b 0
  )
)

type nul >"%PATCH_LOG%"
git apply --reverse --reject --whitespace=nowarn "%PATCH_FILE%" >"%PATCH_LOG%" 2>&1
if not errorlevel 1 (
  call :cleanup_rejects
  if exist "%PATCH_LOG%" del /q "%PATCH_LOG%" >nul 2>&1
  echo [OK] Patch reversed.
  exit /b 0
)

call :has_rejects
if not errorlevel 1 (
  if exist "%PATCH_LOG%" del /q "%PATCH_LOG%" >nul 2>&1
  call :compat_reverse
  if not errorlevel 1 (
    call :has_rejects
    if errorlevel 1 (
      echo [OK] Patch reversed with compatibility fallback.
      exit /b 0
    )
  )
  echo [WARN] Patch partially reversed. Rejected hunks were left as *.rej files.
  echo        Rejected files:
  call :print_rejects
  exit /b 0
)

call :compat_reverse
if not errorlevel 1 (
  call :has_rejects
  if errorlevel 1 (
    echo [OK] Patch reversed with compatibility fallback.
    exit /b 0
  )
)

if exist "%PATCH_LOG%" type "%PATCH_LOG%"
if exist "%PATCH_LOG%" del /q "%PATCH_LOG%" >nul 2>&1
echo [WARN] Reverse apply reported conflicts.
echo        Check *.rej files and resolve manually.
exit /b 1

:cleanup_rejects
for /r "packages\client\src" %%F in (*.rej) do del /q "%%F" >nul 2>&1
if exist "package.json.rej" del /q "package.json.rej" >nul 2>&1
if exist "scripts" for /r "scripts" %%F in (*.rej) do del /q "%%F" >nul 2>&1
exit /b 0

:cleanup_build_outputs
if exist "packages\shared\dist" rmdir /s /q "packages\shared\dist"
if exist "packages\server\dist" rmdir /s /q "packages\server\dist"
if exist "packages\client\dist" rmdir /s /q "packages\client\dist"
del /q "packages\shared\tsconfig.tsbuildinfo" 2>nul
del /q "packages\server\tsconfig.tsbuildinfo" 2>nul
del /q "packages\client\tsconfig.tsbuildinfo" 2>nul
exit /b 0

:compat_apply
if not exist "apply-local-i18n-compat.mjs" exit /b 1
where node >nul 2>&1
if errorlevel 1 exit /b 1
node apply-local-i18n-compat.mjs
exit /b %ERRORLEVEL%

:codemod_apply
if not exist "apply-local-i18n-codemod.mjs" exit /b 1
where node >nul 2>&1
if errorlevel 1 exit /b 1
node apply-local-i18n-codemod.mjs
exit /b %ERRORLEVEL%

:apply_fallbacks
set "FALLBACK_RAN=0"
call :compat_apply
if not errorlevel 1 set "FALLBACK_RAN=1"
call :codemod_apply
if not errorlevel 1 set "FALLBACK_RAN=1"
call :compat_apply
if not errorlevel 1 set "FALLBACK_RAN=1"
if "%FALLBACK_RAN%"=="1" exit /b 0
exit /b 1

:compat_reverse
if not exist "apply-local-i18n-compat.mjs" exit /b 1
where node >nul 2>&1
if errorlevel 1 exit /b 1
node apply-local-i18n-compat.mjs --reverse
exit /b %ERRORLEVEL%

:has_rejects
for /r "packages\client\src" %%F in (*.rej) do exit /b 0
if exist "package.json.rej" exit /b 0
if exist "scripts" for /r "scripts" %%F in (*.rej) do exit /b 0
exit /b 1

:print_rejects
for /r "packages\client\src" %%F in (*.rej) do echo        %%F
if exist "package.json.rej" echo        package.json.rej
if exist "scripts" for /r "scripts" %%F in (*.rej) do echo        %%F
exit /b 0
