#!/usr/bin/env node
import { existsSync, readFileSync, readdirSync, statSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";

const root = resolve("packages/client/src");

function listSourceFiles(dir) {
  if (!existsSync(dir)) return [];

  const files = [];
  for (const entry of readdirSync(dir)) {
    const fullPath = resolve(dir, entry);
    const stat = statSync(fullPath);
    if (stat.isDirectory()) {
      files.push(...listSourceFiles(fullPath));
    } else if (/\.(ts|tsx|js|jsx)$/.test(entry)) {
      files.push(fullPath);
    }
  }
  return files;
}

function skipString(text, index) {
  const quote = text[index];
  let escaped = false;

  for (let i = index + 1; i < text.length; i += 1) {
    const char = text[i];
    if (escaped) {
      escaped = false;
      continue;
    }
    if (char === "\\") {
      escaped = true;
      continue;
    }
    if (char === quote) return i + 1;
  }

  return text.length;
}

function skipTemplate(text, index) {
  let escaped = false;

  for (let i = index + 1; i < text.length; i += 1) {
    const char = text[i];
    if (escaped) {
      escaped = false;
      continue;
    }
    if (char === "\\") {
      escaped = true;
      continue;
    }
    if (char === "`") return i + 1;
  }

  return text.length;
}

function splitTopLevelArgs(argsText) {
  const args = [];
  let start = 0;
  let depth = 0;

  for (let i = 0; i < argsText.length; i += 1) {
    const char = argsText[i];
    if (char === '"' || char === "'") {
      i = skipString(argsText, i) - 1;
      continue;
    }
    if (char === "`") {
      i = skipTemplate(argsText, i) - 1;
      continue;
    }
    if (char === "(" || char === "[" || char === "{") depth += 1;
    if (char === ")" || char === "]" || char === "}") depth -= 1;
    if (char === "," && depth === 0) {
      args.push(argsText.slice(start, i).trim());
      start = i + 1;
    }
  }

  args.push(argsText.slice(start).trim());
  return args;
}

function findCallEnd(text, openParenIndex) {
  let depth = 0;

  for (let i = openParenIndex; i < text.length; i += 1) {
    const char = text[i];
    if (char === '"' || char === "'") {
      i = skipString(text, i) - 1;
      continue;
    }
    if (char === "`") {
      i = skipTemplate(text, i) - 1;
      continue;
    }
    if (char === "(") depth += 1;
    if (char === ")") {
      depth -= 1;
      if (depth === 0) return i;
    }
  }

  return -1;
}

function replaceTranslationCalls(text, name) {
  let output = "";
  let cursor = 0;
  let replacements = 0;
  const needle = `${name}(`;

  while (cursor < text.length) {
    const callStart = text.indexOf(needle, cursor);
    if (callStart === -1) {
      output += text.slice(cursor);
      break;
    }

    const before = callStart === 0 ? "" : text[callStart - 1];
    if (/[A-Za-z0-9_$]/.test(before)) {
      output += text.slice(cursor, callStart + needle.length);
      cursor = callStart + needle.length;
      continue;
    }

    const openParen = callStart + name.length;
    const closeParen = findCallEnd(text, openParen);
    if (closeParen === -1) {
      output += text.slice(cursor);
      break;
    }

    const args = splitTopLevelArgs(text.slice(openParen + 1, closeParen));
    const fallback = args[1];
    if (!fallback) {
      output += text.slice(cursor, closeParen + 1);
      cursor = closeParen + 1;
      continue;
    }

    output += text.slice(cursor, callStart);
    output += fallback;
    cursor = closeParen + 1;
    replacements += 1;
  }

  return { text: output, replacements };
}

function cleanupFile(text) {
  let updated = text;
  let changes = 0;

  const beforeImports = updated;
  updated = updated
    .replace(/^import\s+\{[^}]*\buseT\b[^}]*\}\s+from\s+["'][^"']*\/i18n["'];\r?\n/gm, "")
    .replace(/^import\s+\{[^}]*\buseTRich\b[^}]*\}\s+from\s+["'][^"']*\/i18n["'];\r?\n/gm, "");
  if (updated !== beforeImports) changes += 1;

  for (const name of ["i18n", "i18nr", "tr"]) {
    const result = replaceTranslationCalls(updated, name);
    updated = result.text;
    changes += result.replacements;
  }

  const beforeHooks = updated;
  updated = updated
    .replace(/^\s*const\s+i18n\s*=\s*useT\(\);\r?\n/gm, "")
    .replace(/^\s*const\s+i18nr\s*=\s*useTRich\(\);\r?\n/gm, "")
    .replace(/^\s*const\s+tr\s*=\s*useTRich\(\);\r?\n/gm, "");
  if (updated !== beforeHooks) changes += 1;

  return { text: updated, changes };
}

let changedFiles = 0;
let totalChanges = 0;

for (const file of listSourceFiles(root)) {
  const original = readFileSync(file, "utf8");
  const result = cleanupFile(original);
  if (result.text === original) continue;
  writeFileSync(file, result.text, "utf8");
  changedFiles += 1;
  totalChanges += result.changes;
}

if (changedFiles > 0) {
  console.log(`[INFO] Cleaned i18n leftovers in ${changedFiles} file(s), ${totalChanges} replacement/removal operation(s).`);
}
