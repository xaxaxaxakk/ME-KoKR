#!/usr/bin/env sh
set -eu

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
PATCH_FILE="$SCRIPT_DIR/local-i18n-bootstrap.patch"

make_log_file() {
  if command -v mktemp >/dev/null 2>&1; then
    mktemp "${TMPDIR:-/tmp}/apply-local-i18n.XXXXXX.log"
    return
  fi
  echo "${TMPDIR:-/tmp}/apply-local-i18n.$$.log"
}

cleanup_log() {
  [ -n "${PATCH_LOG:-}" ] && [ -f "$PATCH_LOG" ] && rm -f "$PATCH_LOG"
}

show_log_and_cleanup() {
  if [ -n "${PATCH_LOG:-}" ] && [ -f "$PATCH_LOG" ]; then
    cat "$PATCH_LOG"
    rm -f "$PATCH_LOG"
  fi
}

if ! command -v git >/dev/null 2>&1; then
  echo "[ERROR] git is required."
  exit 1
fi

if [ ! -f "$PATCH_FILE" ]; then
  echo "[ERROR] Patch file not found: $PATCH_FILE"
  exit 1
fi

cd "$SCRIPT_DIR"

if [ "${1:-}" = "--reverse" ]; then
  if git apply --check "$PATCH_FILE" >/dev/null 2>&1; then
    echo "[OK] Patch is not currently applied. Nothing to reverse."
    exit 0
  fi

  PATCH_LOG=$(make_log_file)
  if git apply --reverse --3way --whitespace=nowarn "$PATCH_FILE" >"$PATCH_LOG" 2>&1; then
    find packages/client/src -type f -name "*.rej" -delete 2>/dev/null || true
    cleanup_log
    echo "[OK] Patch reversed."
    exit 0
  fi
  if git apply --reverse --reject --whitespace=nowarn "$PATCH_FILE" >>"$PATCH_LOG" 2>&1; then
    find packages/client/src -type f -name "*.rej" -delete 2>/dev/null || true
    cleanup_log
    echo "[OK] Patch reversed."
    exit 0
  fi
  show_log_and_cleanup
  echo "[WARN] Reverse apply reported conflicts. Check *.rej files and resolve manually."
  exit 1
fi

if git apply --check --reverse "$PATCH_FILE" >/dev/null 2>&1; then
  echo "[OK] Patch already applied. Nothing to do."
  exit 0
fi

PATCH_LOG=$(make_log_file)
if git apply --3way --whitespace=nowarn "$PATCH_FILE" >"$PATCH_LOG" 2>&1; then
  find packages/client/src -type f -name "*.rej" -delete 2>/dev/null || true
  rm -rf packages/shared/dist packages/server/dist packages/client/dist
  rm -f packages/shared/tsconfig.tsbuildinfo packages/server/tsconfig.tsbuildinfo packages/client/tsconfig.tsbuildinfo
  cleanup_log
  echo "[OK] Patch applied."
  exit 0
fi

if git apply --reject --whitespace=nowarn "$PATCH_FILE" >>"$PATCH_LOG" 2>&1; then
  find packages/client/src -type f -name "*.rej" -delete 2>/dev/null || true
  rm -rf packages/shared/dist packages/server/dist packages/client/dist
  rm -f packages/shared/tsconfig.tsbuildinfo packages/server/tsconfig.tsbuildinfo packages/client/tsconfig.tsbuildinfo
  cleanup_log
  echo "[OK] Patch applied."
  exit 0
fi

show_log_and_cleanup
echo "[WARN] Patch apply reported conflicts."
echo "       Resolve *.rej files, then run:"
echo "       your normal Marinara start script"
exit 1

