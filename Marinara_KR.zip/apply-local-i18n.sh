#!/usr/bin/env sh
set -eu

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
PATCH_FILE="$SCRIPT_DIR/local-i18n-bootstrap.patch"

make_log_file() {
  if command -v mktemp >/dev/null 2>&1; then
    mktemp "${TMPDIR:-/tmp}/apply-local-i18n.XXXXXX.log"
    return
  fi
  echo "${TMPDIR:-/tmp}/apply-local-i18n.$$.log"
}

cleanup_log() {
  [ -n "${PATCH_LOG:-}" ] && [ -f "$PATCH_LOG" ] && rm -f "$PATCH_LOG"
}

cleanup_build_outputs() {
  rm -rf packages/shared/dist packages/server/dist packages/client/dist
  rm -f packages/shared/tsconfig.tsbuildinfo packages/server/tsconfig.tsbuildinfo packages/client/tsconfig.tsbuildinfo
}

cleanup_rejects() {
  find packages/client/src -type f -name "*.rej" -delete 2>/dev/null || true
  rm -f package.json.rej
  find scripts -type f -name "*.rej" -delete 2>/dev/null || true
}

run_compat_pass() {
  if [ ! -f "./apply-local-i18n-compat.mjs" ]; then
    return 1
  fi

  if ! command -v node >/dev/null 2>&1; then
    return 1
  fi

  if [ "${1:-}" = "--reverse" ]; then
    node ./apply-local-i18n-compat.mjs --reverse
    return
  fi

  node ./apply-local-i18n-compat.mjs
}

run_codemod_pass() {
  if [ ! -f "./apply-local-i18n-codemod.mjs" ]; then
    return 1
  fi

  if ! command -v node >/dev/null 2>&1; then
    return 1
  fi

  if [ "${1:-}" = "--reverse" ]; then
    return 1
  fi

  node ./apply-local-i18n-codemod.mjs
}

run_apply_fallbacks() {
  run_compat_pass || true
  run_codemod_pass || true
  run_compat_pass || true
}

print_rejects() {
  REJECTS=$(
    {
      find packages/client/src -type f -name "*.rej" 2>/dev/null
      [ -f package.json.rej ] && printf "%s\n" "package.json.rej"
      find scripts -type f -name "*.rej" 2>/dev/null
    } | sort || true
  )
  if [ -z "$REJECTS" ]; then
    return 1
  fi

  printf "%s\n" "$REJECTS" | sed "s/^/       /"
  return 0
}

show_log_and_cleanup() {
  if [ -n "${PATCH_LOG:-}" ] && [ -f "$PATCH_LOG" ]; then
    cat "$PATCH_LOG"
    rm -f "$PATCH_LOG"
  fi
}

if ! command -v git >/dev/null 2>&1; then
  echo "[ERROR] git is required."
  exit 1
fi

if [ ! -f "$PATCH_FILE" ]; then
  echo "[ERROR] Patch file not found: $PATCH_FILE"
  exit 1
fi

cd "$SCRIPT_DIR"

if [ "${1:-}" = "--reverse" ]; then
  if git apply --check "$PATCH_FILE" >/dev/null 2>&1; then
    echo "[OK] Patch is not currently applied. Nothing to reverse."
    exit 0
  fi

  PATCH_LOG=$(make_log_file)
  cleanup_rejects
  if git apply --check --reverse --3way --whitespace=nowarn "$PATCH_FILE" >"$PATCH_LOG" 2>&1 &&
    git apply --reverse --3way --whitespace=nowarn "$PATCH_FILE" >>"$PATCH_LOG" 2>&1; then
    cleanup_rejects
    cleanup_log
    echo "[OK] Patch reversed."
    exit 0
  fi

  : >"$PATCH_LOG"
  if git apply --reverse --reject --whitespace=nowarn "$PATCH_FILE" >"$PATCH_LOG" 2>&1; then
    cleanup_rejects
    cleanup_log
    echo "[OK] Patch reversed."
    exit 0
  fi
  if print_rejects >/dev/null; then
    cleanup_log
    cleanup_build_outputs
    if run_compat_pass --reverse && ! print_rejects >/dev/null; then
      echo "[OK] Patch reversed with compatibility fallback."
      exit 0
    fi
    echo "[WARN] Patch partially reversed. Rejected hunks were left as *.rej files."
    echo "       Rejected files:"
    print_rejects
    exit 0
  fi

  if run_compat_pass --reverse && ! print_rejects >/dev/null; then
    cleanup_build_outputs
    echo "[OK] Patch reversed with compatibility fallback."
    exit 0
  fi

  show_log_and_cleanup
  echo "[WARN] Reverse apply reported conflicts. Check *.rej files and resolve manually."
  exit 1
fi

if git apply --check --reverse "$PATCH_FILE" >/dev/null 2>&1; then
  echo "[OK] Patch already applied. Nothing to do."
  exit 0
fi

PATCH_LOG=$(make_log_file)
cleanup_rejects
if git apply --check --3way --whitespace=nowarn "$PATCH_FILE" >"$PATCH_LOG" 2>&1 &&
  git apply --3way --whitespace=nowarn "$PATCH_FILE" >>"$PATCH_LOG" 2>&1; then
  cleanup_rejects
  cleanup_build_outputs
  cleanup_log
  echo "[OK] Patch applied."
  exit 0
fi

: >"$PATCH_LOG"
if git apply --reject --whitespace=nowarn "$PATCH_FILE" >"$PATCH_LOG" 2>&1; then
  cleanup_rejects
  cleanup_build_outputs
  cleanup_log
  echo "[OK] Patch applied."
  exit 0
fi
if print_rejects >/dev/null; then
  cleanup_log
  cleanup_build_outputs
  run_apply_fallbacks
  if ! print_rejects >/dev/null; then
    echo "[OK] Patch applied with compatibility fallback."
    exit 0
  fi
  echo "[WARN] Patch partially applied. Rejected hunks were left as *.rej files."
  echo "       Most compatible translation hunks were still applied."
  echo "       Rejected files:"
  print_rejects
  exit 0
fi

run_apply_fallbacks
if ! print_rejects >/dev/null; then
  cleanup_build_outputs
  echo "[OK] Patch applied with compatibility fallback."
  exit 0
fi

show_log_and_cleanup
echo "[WARN] Patch apply reported conflicts."
echo "       Resolve *.rej files, then run:"
echo "       your normal Marinara start script"
exit 1
