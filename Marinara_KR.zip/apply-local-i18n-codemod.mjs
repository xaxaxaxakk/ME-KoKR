#!/usr/bin/env node
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, relative, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const scriptDir = dirname(fileURLToPath(import.meta.url));
const patchFile = resolve(scriptDir, "local-i18n-bootstrap.patch");
const i18nDir = resolve(scriptDir, "packages/client/src/i18n");

const ATTR_NAMES = [
  "aria-label",
  "alt",
  "label",
  "placeholder",
  "title",
];

const PROP_NAMES = [
  "cancelLabel",
  "confirmLabel",
  "description",
  "emptyLabel",
  "helperText",
  "label",
  "message",
  "subtitle",
  "text",
  "title",
];

function splitLines(text) {
  return text.replace(/\r\n/g, "\n").replace(/\r/g, "\n").split("\n");
}

function joinLines(lines, trailingNewline) {
  return `${lines.join("\n")}${trailingNewline ? "\n" : ""}`;
}

function parsePatch(patchText) {
  const lines = splitLines(patchText);
  const files = [];
  let current = null;
  let currentHunk = null;

  for (const line of lines) {
    const diffMatch = line.match(/^diff (?:--git )?a\/(.+) b\/(.+?)(?:\s|\t|$)/);
    if (diffMatch) {
      current = { path: diffMatch[2], hunks: [] };
      files.push(current);
      currentHunk = null;
      continue;
    }

    if (!current) continue;
    if (line.startsWith("@@ ")) {
      currentHunk = [];
      current.hunks.push(currentHunk);
      continue;
    }

    if (!currentHunk) continue;
    if (line.startsWith(" ") || line.startsWith("+") || line.startsWith("-")) {
      if (line.startsWith("--- ") || line.startsWith("+++ ")) continue;
      currentHunk.push({ kind: line[0], text: line.slice(1) });
    }
  }

  return files.filter((file) => file.path && file.hunks.length > 0);
}

function buildChangeGroups(hunk) {
  const groups = [];
  let beforeContext = [];
  let active = null;

  const closeActive = (nextContext = []) => {
    if (!active) return;
    active.afterContext = nextContext.slice(0, 4);
    groups.push(active);
    active = null;
  };

  for (const entry of hunk) {
    if (entry.kind === " ") {
      if (active) closeActive([entry.text]);
      beforeContext.push(entry.text);
      if (beforeContext.length > 4) beforeContext.shift();
      continue;
    }

    if (!active) {
      active = { removed: [], added: [], beforeContext: beforeContext.slice(), afterContext: [] };
    }

    if (entry.kind === "-") active.removed.push(entry.text);
    if (entry.kind === "+") active.added.push(entry.text);
  }

  closeActive([]);
  return groups;
}

function escapeRegExp(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function extractCallAt(line, start) {
  let depth = 0;
  let quote = "";
  let escaped = false;

  for (let i = start; i < line.length; i += 1) {
    const char = line[i];

    if (quote) {
      if (escaped) {
        escaped = false;
      } else if (char === "\\") {
        escaped = true;
      } else if (char === quote) {
        quote = "";
      }
      continue;
    }

    if (char === '"' || char === "'") {
      quote = char;
      continue;
    }

    if (char === "(") depth += 1;
    if (char === ")") {
      depth -= 1;
      if (depth === 0) return line.slice(start, i + 1);
    }
  }

  return null;
}

function extractCallExpressions(line) {
  const calls = [];

  for (const name of ["i18n", "tr"]) {
    let offset = 0;
    while (offset < line.length) {
      const index = line.indexOf(`${name}(`, offset);
      if (index === -1) break;
      const before = index === 0 ? "" : line[index - 1];
      if (/[A-Za-z0-9_$]/.test(before)) {
        offset = index + name.length + 1;
        continue;
      }
      const call = extractCallAt(line, index);
      if (call) calls.push(call);
      offset = index + name.length + 1;
    }
  }

  return calls;
}

function decodeBasicStringLiteral(value) {
  return value.replace(/\\(["'\\])/g, "$1").replace(/\\n/g, "\n").replace(/\\t/g, "\t");
}

function getStringLiterals(expression) {
  const strings = [];
  let quote = "";
  let buffer = "";
  let escaped = false;

  for (let i = 0; i < expression.length; i += 1) {
    const char = expression[i];

    if (!quote) {
      if (char === '"' || char === "'") {
        quote = char;
        buffer = "";
      }
      continue;
    }

    if (escaped) {
      buffer += `\\${char}`;
      escaped = false;
      continue;
    }

    if (char === "\\") {
      escaped = true;
      continue;
    }

    if (char === quote) {
      strings.push(decodeBasicStringLiteral(buffer));
      quote = "";
      buffer = "";
      continue;
    }

    buffer += char;
  }

  return strings;
}

function getI18nRules(filePatch) {
  const rules = [];
  const seen = new Set();

  for (const hunk of filePatch.hunks) {
    for (const group of buildChangeGroups(hunk)) {
      const addedCalls = group.added.flatMap((line) => extractCallExpressions(line));
      for (const expression of addedCalls) {
        const strings = getStringLiterals(expression);
        const fallback = strings[1];
        if (!fallback || fallback.length > 160) continue;

        const removedText = group.removed.join("\n");
        if (!removedText.includes(fallback)) continue;

        const key = `${fallback}\u0000${expression}`;
        if (seen.has(key)) continue;
        seen.add(key);
        rules.push({ fallback, expression });
      }
    }
  }

  return rules;
}

function replaceAttribute(line, fallback, expression) {
  let next = line;
  const escaped = escapeRegExp(fallback);

  for (const attr of ATTR_NAMES) {
    const pattern = new RegExp(`\\b${escapeRegExp(attr)}=(["'])${escaped}\\1`, "g");
    next = next.replace(pattern, `${attr}={${expression}}`);
  }

  return next;
}

function replaceObjectProp(line, fallback, expression) {
  let next = line;
  const escaped = escapeRegExp(fallback);

  for (const prop of PROP_NAMES) {
    const pattern = new RegExp(`\\b${escapeRegExp(prop)}\\s*:\\s*(["'])${escaped}\\1`, "g");
    next = next.replace(pattern, `${prop}: ${expression}`);
  }

  return next;
}

function replaceJsxText(line, fallback, expression) {
  if (line.includes(expression)) return line;
  if (line.trim() !== fallback) return line;
  const indent = line.match(/^\s*/)?.[0] ?? "";
  return `${indent}{${expression}}`;
}

function replaceExactKnownLiterals(lines, rules) {
  let changed = false;
  const next = lines.map((line) => {
    let updated = line;

    for (const rule of rules) {
      if (updated.includes(rule.expression)) continue;
      updated = replaceAttribute(updated, rule.fallback, rule.expression);
      updated = replaceObjectProp(updated, rule.fallback, rule.expression);
      updated = replaceJsxText(updated, rule.fallback, rule.expression);
    }

    if (updated !== line) changed = true;
    return updated;
  });

  return { changed, lines: next };
}

function getI18nImportPath(filePath) {
  let importPath = relative(dirname(filePath), i18nDir).replace(/\\/g, "/");
  if (!importPath.startsWith(".")) importPath = `./${importPath}`;
  return importPath;
}

function ensureI18nImport(lines, targetPath) {
  const source = lines.join("\n");
  const needsUseT = /\buseT\s*\(|\bi18n\s*\(/.test(source);
  const needsUseTRich = /\buseTRich\s*\(|\btr\s*\(/.test(source);
  if (!needsUseT && !needsUseTRich) return { changed: false, lines };
  if (/from\s+["'][^"']*\/i18n["']/.test(source)) return { changed: false, lines };

  const names = [];
  if (needsUseT) names.push("useT");
  if (needsUseTRich) names.push("useTRich");

  const importLine = `import { ${names.join(", ")} } from "${getI18nImportPath(targetPath)}";`;
  const insertIndex = lines.findLastIndex((line) => line.startsWith("import "));
  const next = lines.slice();

  if (insertIndex === -1) {
    next.unshift(importLine);
  } else {
    next.splice(insertIndex + 1, 0, importLine);
  }

  return { changed: true, lines: next };
}

if (!existsSync(patchFile)) {
  process.exit(0);
}

let changedFiles = 0;
let changedLines = 0;

for (const filePatch of parsePatch(readFileSync(patchFile, "utf8"))) {
  const targetPath = resolve(scriptDir, filePatch.path);
  if (!existsSync(targetPath) || !/\.(tsx?|jsx?)$/.test(targetPath)) continue;

  const rules = getI18nRules(filePatch);
  if (rules.length === 0) continue;

  const original = readFileSync(targetPath, "utf8").replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  const trailingNewline = original.endsWith("\n");
  let lines = splitLines(original);
  if (trailingNewline) lines.pop();

  const literalResult = replaceExactKnownLiterals(lines, rules);
  lines = literalResult.lines;

  const importResult = ensureI18nImport(lines, targetPath);
  lines = importResult.lines;

  if (!literalResult.changed && !importResult.changed) continue;

  const updated = joinLines(lines, trailingNewline);
  if (updated === original) continue;

  writeFileSync(targetPath, updated, "utf8");
  changedFiles += 1;
  if (literalResult.changed) changedLines += 1;
  if (importResult.changed) changedLines += 1;
}

if (changedFiles > 0) {
  console.log(`[INFO] Codemod fallback updated ${changedFiles} file(s) across ${changedLines} safe operation(s).`);
}
