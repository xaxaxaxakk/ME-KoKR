import { existsSync, readdirSync, readFileSync, statSync } from "node:fs";
import { join, relative, resolve } from "node:path";

const root = process.cwd();
const localeRoot = resolve(root, "packages/client/src/i18n/locales");
const sourceRoot = resolve(root, "packages/client/src");
const defaultLanguage = "en";
const placeholderPattern = /\{[A-Za-z0-9_]+\}/g;
const failures = [];

function rel(path) {
  return relative(root, path).replace(/\\/g, "/");
}

function readJson(path) {
  try {
    const raw = readFileSync(path, "utf8");
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
      failures.push(`${rel(path)} must be a JSON object.`);
      return {};
    }
    for (const [key, value] of Object.entries(parsed)) {
      if (typeof value !== "string") {
        failures.push(`${rel(path)} key "${key}" must have a string value.`);
      }
    }
    return parsed;
  } catch (err) {
    failures.push(`${rel(path)} is not valid JSON: ${err instanceof Error ? err.message : String(err)}`);
    return {};
  }
}

function listLanguageDirs() {
  if (!existsSync(localeRoot)) {
    failures.push(`${rel(localeRoot)} does not exist.`);
    return [];
  }

  return readdirSync(localeRoot)
    .map((name) => join(localeRoot, name))
    .filter((path) => statSync(path).isDirectory())
    .map((path) => path.split(/[/\\]/).pop())
    .filter(Boolean)
    .sort();
}

function listNamespaceFiles(language) {
  const dir = join(localeRoot, language);
  if (!existsSync(dir)) return [];
  return readdirSync(dir).filter((name) => name.endsWith(".json")).sort();
}

function placeholders(value) {
  return Array.from(new Set(value.match(placeholderPattern) ?? [])).sort();
}

function sameList(left, right) {
  return left.length === right.length && left.every((value, index) => value === right[index]);
}

function collectSourceFiles(dir) {
  const files = [];
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const path = join(dir, entry.name);
    if (entry.isDirectory()) {
      if (entry.name === "locales") continue;
      files.push(...collectSourceFiles(path));
      continue;
    }
    if (/\.(tsx?|jsx?)$/.test(entry.name)) files.push(path);
  }
  return files;
}

const languages = listLanguageDirs();
const defaultNamespaces = listNamespaceFiles(defaultLanguage);
const defaultByNamespace = new Map();
const defaultKeyNamespace = new Map();
const defaultKeys = new Set();

for (const namespaceFile of defaultNamespaces) {
  const path = join(localeRoot, defaultLanguage, namespaceFile);
  const dict = readJson(path);
  defaultByNamespace.set(namespaceFile, dict);

  for (const key of Object.keys(dict)) {
    if (defaultKeyNamespace.has(key)) {
      failures.push(
        `Duplicate default translation key "${key}" in ${namespaceFile} and ${defaultKeyNamespace.get(key)}.`,
      );
    }
    defaultKeyNamespace.set(key, namespaceFile);
    defaultKeys.add(key);
  }
}

for (const language of languages) {
  const namespaceFiles = listNamespaceFiles(language);
  const namespaceSet = new Set(namespaceFiles);
  const allLanguageKeys = new Set();
  const languageDict = {};

  for (const namespaceFile of defaultNamespaces) {
    if (!namespaceSet.has(namespaceFile)) {
      failures.push(`${language} is missing namespace ${namespaceFile}.`);
      continue;
    }

    const defaultDict = defaultByNamespace.get(namespaceFile) ?? {};
    const path = join(localeRoot, language, namespaceFile);
    const dict = readJson(path);

    for (const [key, value] of Object.entries(dict)) {
      allLanguageKeys.add(key);
      languageDict[key] = value;
    }

    const defaultKeysInFile = Object.keys(defaultDict).sort();
    const keysInFile = Object.keys(dict).sort();
    const missing = defaultKeysInFile.filter((key) => !Object.hasOwn(dict, key));
    const extra = keysInFile.filter((key) => !Object.hasOwn(defaultDict, key));

    for (const key of missing) failures.push(`${language}/${namespaceFile} is missing key "${key}".`);
    for (const key of extra) failures.push(`${language}/${namespaceFile} has extra key "${key}".`);

    for (const key of defaultKeysInFile) {
      if (!Object.hasOwn(dict, key)) continue;
      const expected = placeholders(defaultDict[key]);
      const actual = placeholders(dict[key]);
      if (!sameList(expected, actual)) {
        failures.push(
          `${language}/${namespaceFile} key "${key}" placeholders differ: expected [${expected.join(", ")}], got [${actual.join(", ")}].`,
        );
      }
    }
  }

  for (const namespaceFile of namespaceFiles) {
    if (!defaultByNamespace.has(namespaceFile)) {
      failures.push(`${language} has namespace ${namespaceFile}, but ${defaultLanguage} does not.`);
    }
  }

  for (const [key, value] of Object.entries(languageDict)) {
    if (!value.startsWith("@:")) continue;
    const target = value.slice(2).trim();
    if (!target) {
      failures.push(`${language} key "${key}" has an empty @: reference.`);
    } else if (!Object.hasOwn(languageDict, target) && !defaultKeys.has(target)) {
      failures.push(`${language} key "${key}" references missing translation key "${target}".`);
    }
  }
}

for (const path of collectSourceFiles(sourceRoot)) {
  const source = readFileSync(path, "utf8");

  const malformedCallPattern = /\bi18n\s*\(\s*["'][^"']+["']\s*\./g;
  let malformed;
  while ((malformed = malformedCallPattern.exec(source))) {
    failures.push(`${rel(path)} has an i18n() call that mutates the key before translation.`);
  }

  const literalCallPattern = /\b(?:i18n|i18t)\s*\(\s*["']([^"']+)["']/g;
  let match;
  while ((match = literalCallPattern.exec(source))) {
    const key = match[1];
    if (!defaultKeys.has(key)) {
      failures.push(`${rel(path)} references missing translation key "${key}".`);
    }
  }
}

if (failures.length > 0) {
  console.error(`i18n check failed with ${failures.length} issue${failures.length === 1 ? "" : "s"}:`);
  for (const failure of failures) console.error(`- ${failure}`);
  process.exit(1);
}

console.log(`i18n check passed for ${languages.length} languages and ${defaultKeys.size} keys.`);
